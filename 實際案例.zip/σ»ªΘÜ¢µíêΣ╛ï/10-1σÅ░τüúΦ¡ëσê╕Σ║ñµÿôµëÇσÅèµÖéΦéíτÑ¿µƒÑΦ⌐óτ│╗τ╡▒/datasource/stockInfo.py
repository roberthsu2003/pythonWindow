class StockInfo():
    def __init__(self):
        self.name = None
        self.time = None
        self.open = None
        self.close = None
        self.high = None
        self.low = None
        self.volume = None
        self.millionAmount = None
        self.error = None
        self.diff = None
        self.percent = None
        self.tv_odd = None #當盤成交量
        self.v_odd = None #累積_成交量
